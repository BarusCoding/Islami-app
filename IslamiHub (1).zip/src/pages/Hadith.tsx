import { useState } from 'react';

interface Hadith {
  id: number;
  title: string;
  arabic: string;
  content: string;
  source: string;
  category: string;
  narrator: string;
}

const hadiths: Hadith[] = [
  {
    id: 1,
    title: "Niat dalam Beramal",
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    content: "Sesungguhnya setiap amalan tergantung pada niatnya. Dan sesungguhnya setiap orang akan mendapatkan apa yang ia niatkan.",
    source: "Sahih Bukhari & Muslim",
    category: "akhlak",
    narrator: "Umar bin Khattab"
  },
  {
    id: 2,
    title: "Senyum Adalah Sedekah",
    arabic: "تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ صَدَقَةٌ",
    content: "Senyummu di hadapan saudaramu adalah sedekah.",
    source: "Sunan Tirmidzi",
    category: "akhlak",
    narrator: "Abu Dzar Al-Ghifari"
  },
  {
    id: 3,
    title: "Kebersihan",
    arabic: "الطُّهُورُ شَطْرُ الإِيمَانِ",
    content: "Kebersihan adalah sebagian dari iman.",
    source: "Sahih Muslim",
    category: "ibadah",
    narrator: "Abu Malik Al-Asy'ari"
  },
  {
    id: 4,
    title: "Larangan Berbuat Kerusakan",
    arabic: "لاَ ضَرَرَ وَلاَ ضِرَارَ",
    content: "Tidak boleh membahayakan diri sendiri dan tidak boleh membahayakan orang lain.",
    source: "Sunan Ibnu Majah",
    category: "muamalah",
    narrator: "Abu Sa'id Al-Khudri"
  },
  {
    id: 5,
    title: "Keutamaan Ilmu",
    arabic: "طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ",
    content: "Menuntut ilmu adalah kewajiban bagi setiap muslim.",
    source: "Sunan Ibnu Majah",
    category: "ilmu",
    narrator: "Anas bin Malik"
  },
  {
    id: 6,
    title: "Saling Mencintai",
    arabic: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ",
    content: "Tidak sempurna iman seseorang di antara kalian hingga ia mencintai untuk saudaranya apa yang ia cintai untuk dirinya sendiri.",
    source: "Sahih Bukhari",
    category: "akhlak",
    narrator: "Abdullah bin Amr"
  },
  {
    id: 7,
    title: "Keutamaan Memberi",
    arabic: "الْيَدُ الْعُلْيَا خَيْرٌ مِنَ الْيَدِ السُّفْلَى",
    content: "Tangan yang di atas lebih baik daripada tangan yang di bawah.",
    source: "Sahih Bukhari",
    category: "muamalah",
    narrator: "Abdullah bin Umar"
  },
  {
    id: 8,
    title: "Istiqamah",
    arabic: "قُلْ آمَنْتُ بِاللَّهِ ثُمَّ اسْتَقِمْ",
    content: "Katakanlah, 'Aku beriman kepada Allah,' kemudian istiqamahlah.",
    source: "Sahih Muslim",
    category: "aqidah",
    narrator: "Sufyan bin Abdullah Ats-Tsaqafi"
  }
];

const categories = [
  { id: 'semua', name: 'Semua Kategori' },
  { id: 'akhlak', name: 'Akhlak' },
  { id: 'ibadah', name: 'Ibadah' },
  { id: 'muamalah', name: 'Muamalah' },
  { id: 'ilmu', name: 'Ilmu' },
  { id: 'aqidah', name: 'Aqidah' }
];

const sources = [
  { id: 'semua', name: 'Semua Sumber' },
  { id: 'Sahih Bukhari', name: 'Sahih Bukhari' },
  { id: 'Sahih Muslim', name: 'Sahih Muslim' },
  { id: 'Sunan Tirmidzi', name: 'Sunan Tirmidzi' },
  { id: 'Sunan Ibnu Majah', name: 'Sunan Ibnu Majah' }
];

const Hadith = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('semua');
  const [selectedSource, setSelectedSource] = useState('semua');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filteredHadiths = hadiths.filter(hadith => {
    const matchesSearch = hadith.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          hadith.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          hadith.narrator.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'semua' || hadith.category === selectedCategory;
    const matchesSource = selectedSource === 'semua' || hadith.source.includes(selectedSource);
    
    return matchesSearch && matchesCategory && matchesSource;
  });

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Kumpulan Hadits</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Kumpulan hadits-hadits shahih untuk meningkatkan keimanan dan ketaqwaan
        </p>
      </div>

      <div className="card mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Cari hadits..."
              className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <select
              className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
            <select
              className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={selectedSource}
              onChange={(e) => setSelectedSource(e.target.value)}
            >
              {sources.map(source => (
                <option key={source.id} value={source.id}>{source.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filteredHadiths.length === 0 ? (
          <div className="card text-center py-8">
            <p>Tidak ada hadits yang ditemukan</p>
          </div>
        ) : (
          filteredHadiths.map(hadith => (
            <div key={hadith.id} className="card">
              <div 
                className="flex justify-between items-center cursor-pointer"
                onClick={() => toggleExpand(hadith.id)}
              >
                <div>
                  <h2 className="font-semibold">{hadith.title}</h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Diriwayatkan oleh {hadith.narrator}
                  </p>
                </div>
                <div className="w-6 h-6 flex items-center justify-center">
                  <span className="text-lg">{expandedId === hadith.id ? '−' : '+'}</span>
                </div>
              </div>
              
              {expandedId === hadith.id && (
                <div className="mt-4 space-y-4 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="arabic-text text-xl text-center py-2">
                    {hadith.arabic}
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <p className="mb-2">{hadith.content}</p>
                    <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span>Sumber: {hadith.source}</span>
                      <span className="capitalize">Kategori: {hadith.category}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Hadith;
