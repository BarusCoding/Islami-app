import { useState, useEffect } from 'react';
import { RotateCcw } from 'lucide-react';

const Dhikr = () => {
  const [count, setCount] = useState(() => {
    const saved = localStorage.getItem('dhikrCount');
    return saved ? parseInt(saved, 10) : 0;
  });
  
  const [targetCount, setTargetCount] = useState(() => {
    const saved = localStorage.getItem('dhikrTarget');
    return saved ? parseInt(saved, 10) : 33;
  });
  
  const [vibrate, setVibrate] = useState(() => {
    const saved = localStorage.getItem('dhikrVibrate');
    return saved ? saved === 'true' : true;
  });

  useEffect(() => {
    localStorage.setItem('dhikrCount', count.toString());
    localStorage.setItem('dhikrTarget', targetCount.toString());
    localStorage.setItem('dhikrVibrate', vibrate.toString());
    
    if (count > 0 && count === targetCount && vibrate) {
      if ('vibrate' in navigator) {
        navigator.vibrate(200);
      }
    }
  }, [count, targetCount, vibrate]);

  const increment = () => {
    setCount(prev => prev + 1);
  };

  const reset = () => {
    setCount(0);
  };

  const handleTargetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setTargetCount(parseInt(e.target.value, 10));
  };

  const toggleVibrate = () => {
    setVibrate(prev => !prev);
  };

  const getProgressPercentage = () => {
    return Math.min((count / targetCount) * 100, 100);
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Dzikir Digital</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Alat bantu untuk menghitung dzikir
        </p>
      </div>

      <div className="card mb-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <label htmlFor="target-count" className="block text-sm font-medium mb-1">
              Target Hitungan
            </label>
            <select
              id="target-count"
              className="px-3 py-1 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={targetCount}
              onChange={handleTargetChange}
            >
              <option value="33">33 (Tasbih)</option>
              <option value="99">99 (Asmaul Husna)</option>
              <option value="100">100</option>
              <option value="1000">1000</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="vibrate-toggle" className="text-sm font-medium">
              Getar
            </label>
            <button
              id="vibrate-toggle"
              onClick={toggleVibrate}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                vibrate ? 'bg-emerald-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  vibrate ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="mb-4 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-500 transition-all duration-300 ease-out"
            style={{ width: `${getProgressPercentage()}%` }}
          ></div>
        </div>

        <div className="flex justify-between text-sm mb-6">
          <div>{count} hitungan</div>
          <div>Target: {targetCount}</div>
        </div>

        <div className="relative">
          <button
            onClick={increment}
            className="w-full aspect-square rounded-full bg-emerald-50 dark:bg-emerald-900/20 border-4 border-emerald-500 flex items-center justify-center text-5xl font-bold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 active:transform active:scale-95 transition"
          >
            {count}
          </button>
          
          <button
            onClick={reset}
            className="absolute -top-2 -right-2 p-2 rounded-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 shadow-sm hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Reset counter"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>

      <div className="card text-center">
        <h2 className="text-lg font-semibold mb-2">Bacaan Tasbih</h2>
        
        <div className="mb-4">
          <p className="arabic-text text-xl mb-2">سُبْحَانَ اللهِ</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Subhanallah (33x)</p>
        </div>
        
        <div className="mb-4">
          <p className="arabic-text text-xl mb-2">اَلْحَمْدُ لِلهِ</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Alhamdulillah (33x)</p>
        </div>
        
        <div>
          <p className="arabic-text text-xl mb-2">اللهُ أَكْبَرُ</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Allahu Akbar (33x)</p>
        </div>
      </div>
    </div>
  );
};

export default Dhikr;
