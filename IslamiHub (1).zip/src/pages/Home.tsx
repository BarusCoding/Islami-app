import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Moon, Send } from 'lucide-react';
import axios from 'axios';

interface PrayerTime {
  fajr: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

interface Hadith {
  id: number;
  title: string;
  arabic: string;
  content: string;
  source: string;
  narrator: string;
}

// Featured hadiths for homepage
const featuredHadiths: Hadith[] = [
  {
    id: 1,
    title: "Niat dalam Beramal",
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    content: "Sesungguhnya setiap amalan tergantung pada niatnya. Dan sesungguhnya setiap orang akan mendapatkan apa yang ia niatkan.",
    source: "Sahih Bukhari & Muslim",
    narrator: "Umar bin Khattab"
  },
  {
    id: 2,
    title: "Senyum Adalah Sedekah",
    arabic: "تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ صَدَقَةٌ",
    content: "Senyummu di hadapan saudaramu adalah sedekah.",
    source: "Sunan Tirmidzi",
    narrator: "Abu Dzar Al-Ghifari"
  },
  {
    id: 3,
    title: "Kebersihan",
    arabic: "الطُّهُورُ شَطْرُ الإِيمَانِ",
    content: "Kebersihan adalah sebagian dari iman.",
    source: "Sahih Muslim",
    narrator: "Abu Malik Al-Asy'ari"
  }
];

// Predefined Islamic Q&A responses for demo
const islamicResponses = [
  {
    keywords: ["shalat", "salat", "solat", "sembahyang", "rukun shalat", "waktu shalat"],
    answer: "Shalat adalah salah satu rukun Islam yang wajib dilaksanakan 5 kali sehari oleh setiap Muslim yang telah baligh dan berakal. Allah SWT berfirman dalam Al-Quran (QS. Al-Baqarah: 43): \"Dan dirikanlah shalat, tunaikanlah zakat dan ruku'lah beserta orang-orang yang ruku'.\" Waktu shalat yang diwajibkan adalah Subuh, Dzuhur, Ashar, Maghrib, dan Isya."
  },
  {
    keywords: ["puasa", "ramadhan", "ramadan", "berpuasa", "berbuka"],
    answer: "Puasa Ramadhan adalah kewajiban bagi setiap Muslim yang baligh dan berakal. Allah SWT berfirman dalam Al-Quran (QS. Al-Baqarah: 183): \"Hai orang-orang yang beriman, diwajibkan atas kamu berpuasa sebagaimana diwajibkan atas orang-orang sebelum kamu agar kamu bertakwa.\" Puasa dilaksanakan dengan menahan diri dari makan, minum, dan hal-hal yang membatalkan puasa dari terbit fajar hingga terbenamnya matahari."
  },
  {
    keywords: ["zakat", "sedekah", "infaq", "harta"],
    answer: "Zakat adalah rukun Islam ketiga yang wajib dikeluarkan oleh setiap Muslim yang hartanya telah mencapai nisab. Allah SWT berfirman dalam Al-Quran (QS. At-Taubah: 103): \"Ambillah zakat dari sebagian harta mereka, dengan zakat itu kamu membersihkan dan mensucikan mereka.\" Zakat membersihkan harta dan jiwa, serta membantu orang yang membutuhkan."
  },
  {
    keywords: ["dosa", "tobat", "taubat", "ampunan", "istighfar"],
    answer: "Allah Maha Pengampun bagi hamba-Nya yang bertaubat dengan sungguh-sungguh. Allah SWT berfirman dalam Al-Quran (QS. Az-Zumar: 53): \"Katakanlah: 'Hai hamba-hamba-Ku yang melampaui batas terhadap diri mereka sendiri, janganlah kamu berputus asa dari rahmat Allah. Sesungguhnya Allah mengampuni dosa-dosa semuanya. Sesungguhnya Dialah Yang Maha Pengampun lagi Maha Penyayang.'\" Syarat taubat adalah menyesali perbuatan, meninggalkan perbuatan dosa, dan bertekad untuk tidak mengulanginya."
  },
  {
    keywords: ["halal", "haram", "makanan", "minuman", "jual beli"],
    answer: "Islam menetapkan aturan halal dan haram untuk kebaikan umat manusia. Allah SWT berfirman dalam Al-Quran (QS. Al-Baqarah: 168): \"Hai sekalian manusia, makanlah yang halal lagi baik dari apa yang terdapat di bumi, dan janganlah kamu mengikuti langkah-langkah syaitan; karena sesungguhnya syaitan itu adalah musuh yang nyata bagimu.\" Segala sesuatu pada dasarnya halal kecuali yang secara khusus diharamkan dalam Al-Quran dan Hadits."
  },
  {
    keywords: ["nikah", "pernikahan", "kawin", "menikah", "jodoh"],
    answer: "Pernikahan dalam Islam adalah ikatan yang sangat sakral dan dianjurkan bagi yang telah mampu. Rasulullah SAW bersabda: \"Pernikahan adalah sunnahku, barangsiapa tidak mengamalkan sunnahku maka ia bukan dari golonganku.\" (HR. Ibnu Majah). Allah SWT berfirman dalam Al-Quran (QS. Ar-Rum: 21): \"Dan di antara tanda-tanda kekuasaan-Nya ialah Dia menciptakan untukmu istri-istri dari jenismu sendiri, supaya kamu cenderung dan merasa tenteram kepadanya, dan dijadikan-Nya diantaramu rasa kasih dan sayang.\""
  },
  {
    keywords: ["al-quran", "quran", "kitab", "ayat", "surah", "membaca quran"],
    answer: "Al-Quran adalah Kitab Suci umat Islam yang berisi firman Allah SWT yang diturunkan kepada Nabi Muhammad SAW melalui malaikat Jibril. Allah SWT berfirman tentang Al-Quran (QS. Al-Isra: 9): \"Sesungguhnya Al-Quran ini memberikan petunjuk kepada (jalan) yang lebih lurus dan memberi kabar gembira kepada orang-orang yang beriman yang mengerjakan amal saleh bahwa bagi mereka ada pahala yang besar.\" Membaca Al-Quran merupakan ibadah dan setiap hurufnya mengandung 10 kebaikan."
  },
  {
    keywords: ["nabi", "rasul", "muhammad", "sunnah", "hadits"],
    answer: "Nabi Muhammad SAW adalah Rasul terakhir yang diutus Allah SWT kepada seluruh umat manusia. Allah SWT berfirman dalam Al-Quran (QS. Al-Ahzab: 21): \"Sesungguhnya telah ada pada (diri) Rasulullah itu suri teladan yang baik bagimu (yaitu) bagi orang yang mengharap (rahmat) Allah dan (kedatangan) hari kiamat dan dia banyak menyebut Allah.\" Mengikuti sunnah Rasulullah SAW adalah bagian dari ketaatan kepada Allah SWT."
  },
  {
    keywords: ["doa", "berdoa", "meminta", "hajat"],
    answer: "Doa adalah ibadah dan bentuk komunikasi hamba dengan Allah SWT. Allah SWT berfirman dalam Al-Quran (QS. Al-Baqarah: 186): \"Dan apabila hamba-hamba-Ku bertanya kepadamu tentang Aku, maka (jawablah), bahwasanya Aku adalah dekat. Aku mengabulkan permohonan orang yang berdoa apabila ia memohon kepada-Ku, maka hendaklah mereka itu memenuhi (segala perintah-Ku) dan hendaklah mereka beriman kepada-Ku, agar mereka selalu berada dalam kebenaran.\""
  },
  {
    keywords: ["surga", "neraka", "akhirat", "kiamat", "hari akhir"],
    answer: "Iman kepada hari akhir adalah salah satu rukun iman. Allah SWT menggambarkan surga dalam Al-Quran (QS. Ali Imran: 133): \"Dan bersegeralah kamu kepada ampunan dari Tuhanmu dan kepada surga yang luasnya seluas langit dan bumi yang disediakan untuk orang-orang yang bertakwa.\" Sedangkan tentang neraka Allah SWT berfirman (QS. Az-Zumar: 71-72): \"Orang-orang kafir dibawa ke neraka Jahannam berombongan-berombongan... Dikatakan (kepada mereka): 'Masuklah kamu ke pintu-pintu neraka Jahannam, sedang kamu kekal di dalamnya.' Maka neraka Jahannam itulah seburuk-buruk tempat bagi orang-orang yang menyombongkan diri.\""
  }
];

// Generic fallback response
const fallbackResponse = "Berdasarkan ajaran Islam, setiap pertanyaan perlu dijawab dengan ilmu dan pemahaman yang benar. Mohon maaf, untuk pertanyaan spesifik ini lebih baik berkonsultasi dengan ulama atau ahli agama yang berkompeten. Nabi Muhammad SAW bersabda: \"Mencari ilmu itu wajib bagi setiap muslim\" (HR. Ibnu Majah), sehingga disarankan untuk terus mencari ilmu dari sumber-sumber yang terpercaya.";

const Home = () => {
  const navigate = useNavigate();
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [userLocation, setUserLocation] = useState('');
  const [featuredHadithIndex, setFeaturedHadithIndex] = useState(0);
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    return localStorage.getItem('prayerNotifications') === 'true';
  });
  const [userName, setUserName] = useState(() => {
    return localStorage.getItem('userName') || 'Saudaraku';
  });
  
  // Q&A States
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const [recentQuestions, setRecentQuestions] = useState<{question: string, answer: string}[]>(() => {
    const saved = localStorage.getItem('recentQuestions');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    // Set up timer to update the current time every minute
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    
    // Get saved location preferences
    const savedProvince = localStorage.getItem('selectedProvince');
    const savedDistrict = localStorage.getItem('selectedDistrict');
    const savedSubdistrict = localStorage.getItem('selectedSubdistrict');

    // Try to get user's actual location if they haven't set a preference
    if (!savedProvince && !savedDistrict && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          try {
            const response = await axios.get(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
            );
            if (response.data) {
              const location = response.data.display_name.split(', ');
              // Get city or town name from location
              const locationName = location[0] || 'Jakarta';
              setUserLocation(locationName);
              fetchPrayerTimes(locationName);
            } else {
              setDefaultLocation();
            }
          } catch (error) {
            console.error("Error fetching location data:", error);
            setDefaultLocation();
          }
        },
        (error) => {
          console.error("Error getting location:", error);
          setDefaultLocation();
        }
      );
    } else {
      let locationName = '';
      if (savedProvince === 'sumatera_utara' && savedDistrict) {
        // For Sumatera Utara we might have district and subdistrict info
        locationName = savedDistrict.replace('_', ' ').split(' ').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
        
        if (savedSubdistrict) {
          const subdistrict = savedSubdistrict.replace('_', ' ').split(' ').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
          ).join(' ');
          setUserLocation(`${subdistrict}, ${locationName}, Sumatera Utara`);
        } else {
          setUserLocation(`${locationName}, Sumatera Utara`);
        }
      } else if (savedDistrict) {
        // For other provinces, we use the city name
        locationName = savedDistrict;
        setUserLocation(locationName);
      } else {
        setDefaultLocation();
      }
      
      fetchPrayerTimes(locationName || 'Jakarta');
    }

    // Rotate featured hadith every 30 seconds
    const hadithRotator = setInterval(() => {
      setFeaturedHadithIndex(prev => (prev + 1) % featuredHadiths.length);
    }, 30000);
    
    return () => {
      clearInterval(timer);
      clearInterval(hadithRotator);
    };
  }, []);

  // Save recent questions to localStorage
  useEffect(() => {
    localStorage.setItem('recentQuestions', JSON.stringify(recentQuestions));
  }, [recentQuestions]);

  const setDefaultLocation = () => {
    // Default
    setUserLocation('Jakarta');
  };
  
  const fetchPrayerTimes = async (city: string) => {
    setLoading(true);
    try {
      const today = new Date();
      // Include date in the API call for more accurate times
      const response = await axios.get(`https://api.aladhan.com/v1/timingsByCity`, {
        params: {
          city,
          country: 'Indonesia',
          method: 2, // Islamic Society of North America method
          date: `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`
        }
      });
      
      const timings = response.data.data.timings;
      setPrayerTimes({
        fajr: timings.Fajr,
        dhuhr: timings.Dhuhr,
        asr: timings.Asr,
        maghrib: timings.Maghrib,
        isha: timings.Isha
      });

      // Set up notifications if enabled
      if (notificationsEnabled && "Notification" in window && Notification.permission === "granted") {
        schedulePrayerNotifications({
          fajr: timings.Fajr,
          dhuhr: timings.Dhuhr,
          asr: timings.Asr,
          maghrib: timings.Maghrib,
          isha: timings.Isha
        });
      }
    } catch (error) {
      console.error('Error fetching prayer times:', error);
      // Fallback data for demo purposes
      setPrayerTimes({
        fajr: '04:30',
        dhuhr: '12:05',
        asr: '15:25',
        maghrib: '18:02',
        isha: '19:15'
      });
    } finally {
      setLoading(false);
    }
  };

  const schedulePrayerNotifications = (times: Record<string, string>) => {
    // We'd need to calculate the time until each prayer and set timeouts
    const prayerNames = {
      fajr: "Subuh",
      dhuhr: "Dzuhur",
      asr: "Ashar",
      maghrib: "Maghrib",
      isha: "Isya"
    };
    
    Object.entries(times).forEach(([prayer, time]) => {
      if (prayer in prayerNames) {
        const [hours, minutes] = time.split(':').map(Number);
        const prayerTime = new Date();
        prayerTime.setHours(hours, minutes, 0);
        
        const now = new Date();
        let timeUntilPrayer = prayerTime.getTime() - now.getTime();
        
        // If the prayer time has already passed today, skip it
        if (timeUntilPrayer > 0) {
          setTimeout(() => {
            // This would show a notification when prayer time arrives
            new Notification(`Waktu Shalat ${prayerNames[prayer as keyof typeof prayerNames]}`, {
              body: `Sekarang waktu shalat ${prayerNames[prayer as keyof typeof prayerNames]}: ${time}`,
              icon: "/mosque-icon.png"
            });
            
            // Play adhan sound (in a real app)
            console.log(`Adhan would play for ${prayerNames[prayer as keyof typeof prayerNames]}`);
          }, timeUntilPrayer);
        }
      }
    });
  };
  
  const formatToday = () => {
    return new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(currentTime);
  };
  
  const formatTime = () => {
    return currentTime.toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const getNextPrayer = () => {
    if (!prayerTimes) return null;
    
    const now = currentTime;
    const times = [
      { name: 'Subuh', time: prayerTimes.fajr },
      { name: 'Dzuhur', time: prayerTimes.dhuhr },
      { name: 'Ashar', time: prayerTimes.asr },
      { name: 'Maghrib', time: prayerTimes.maghrib },
      { name: 'Isya', time: prayerTimes.isha },
    ];
    
    // Convert prayer times to Date objects for comparison
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    for (const prayer of times) {
      const [hour, minute] = prayer.time.split(':').map(Number);
      if ((hour > currentHour) || (hour === currentHour && minute > currentMinute)) {
        return prayer;
      }
    }
    
    // If all prayers passed for today, return the first prayer for tomorrow
    return times[0];
  };

  const handleAskQuestion = async () => {
    if (!question.trim()) return;
    
    setIsAsking(true);
    setAnswer('');
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Find a matching response from our predefined answers
    let matchedResponse = fallbackResponse;
    
    for (const response of islamicResponses) {
      // Check if the question contains any of the keywords
      if (response.keywords.some(keyword => 
        question.toLowerCase().includes(keyword.toLowerCase())
      )) {
        matchedResponse = response.answer;
        break;
      }
    }
    
    setAnswer(matchedResponse);
    
    // Add to recent questions (max 3)
    setRecentQuestions(prev => {
      const updated = [{ question, answer: matchedResponse }, ...prev];
      return updated.slice(0, 3); // Keep only the 3 most recent
    });
    
    setIsAsking(false);
  };
  
  const nextPrayer = getNextPrayer();
  const currentFeaturedHadith = featuredHadiths[featuredHadithIndex];

  return (
    <div className="space-y-6">
      {/* Greeting Card */}
      <div className="card bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
        <div className="mb-2 text-xl font-bold">
          السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ
        </div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl font-semibold">Selamat datang, {userName}</h2>
            <p className="text-lg">{formatToday()} - {formatTime()}</p>
          </div>
          <div className="text-right flex items-center gap-2">
            <MapPin size={16} />
            <div className="font-semibold">{userLocation}</div>
          </div>
        </div>
      </div>
      
      {/* Prayer Times Card */}
      <div className="card">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Jadwal Shalat Hari Ini</h2>
          <button 
            onClick={() => navigate('/prayer-times')}
            className="text-xs text-emerald-600 dark:text-emerald-400 font-medium border border-emerald-200 dark:border-emerald-800 rounded-md px-2 py-1 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
          >
            Ubah Lokasi
          </button>
        </div>
        {loading ? (
          <div className="flex justify-center items-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div>
            {nextPrayer && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800">
                <p className="text-sm">Shalat berikutnya</p>
                <p className="text-lg font-bold">{nextPrayer.name} - {nextPrayer.time}</p>
              </div>
            )}
            
            <div className="grid grid-cols-5 gap-2 text-center">
              <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                <p className="text-xs mb-1">Subuh</p>
                <p className="font-semibold">{prayerTimes?.fajr}</p>
              </div>
              <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                <p className="text-xs mb-1">Dzuhur</p>
                <p className="font-semibold">{prayerTimes?.dhuhr}</p>
              </div>
              <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                <p className="text-xs mb-1">Ashar</p>
                <p className="font-semibold">{prayerTimes?.asr}</p>
              </div>
              <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                <p className="text-xs mb-1">Maghrib</p>
                <p className="font-semibold">{prayerTimes?.maghrib}</p>
              </div>
              <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                <p className="text-xs mb-1">Isya</p>
                <p className="font-semibold">{prayerTimes?.isha}</p>
              </div>
            </div>
            
            <div className="mt-4 text-center">
              <button 
                onClick={() => navigate('/prayer-times')}
                className="text-emerald-600 dark:text-emerald-400 text-sm font-medium"
              >
                Lihat jadwal lengkap
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Islamic Q&A Card */}
      <div className="card bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/30 dark:to-purple-900/30 border border-indigo-100 dark:border-indigo-800/50">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-indigo-700 dark:text-indigo-300">Tanya Jawab Islami</h2>
          <p className="text-sm text-indigo-600/80 dark:text-indigo-400/80">
            Ajukan pertanyaan seputar Islam, Al-Quran, dan sunnah
          </p>
        </div>

        <div className="space-y-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Tulis pertanyaan Anda di sini..."
              className="w-full px-4 py-3 pr-12 rounded-lg border border-indigo-200 dark:border-indigo-700 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !isAsking) {
                  handleAskQuestion();
                }
              }}
              disabled={isAsking}
            />
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full text-indigo-600 hover:bg-indigo-50 dark:text-indigo-400 dark:hover:bg-indigo-900/30 disabled:opacity-50"
              onClick={handleAskQuestion}
              disabled={!question.trim() || isAsking}
            >
              <Send size={18} />
            </button>
          </div>

          {isAsking && (
            <div className="flex justify-center py-4">
              <div className="flex space-x-2 items-center">
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0s' }}></div>
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                <span className="text-sm text-indigo-600 dark:text-indigo-400 ml-2">Mencari jawaban...</span>
              </div>
            </div>
          )}

          {answer && (
            <div className="mt-4 bg-white dark:bg-gray-800 rounded-lg p-4 border border-indigo-100 dark:border-indigo-800/50 shadow-sm">
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Pertanyaan:</div>
              <div className="font-medium mb-3">{question}</div>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Jawaban:</div>
              <div className="text-gray-800 dark:text-gray-200">{answer}</div>
              <div className="mt-3 text-right">
                <div className="text-xs text-indigo-500 dark:text-indigo-400">
                  Dijawab berdasarkan Al-Quran dan sumber islami
                </div>
              </div>
            </div>
          )}

          {recentQuestions.length > 0 && !answer && !isAsking && (
            <div className="mt-2">
              <div className="text-sm text-indigo-600/80 dark:text-indigo-400/80 mb-2">
                Pertanyaan Sebelumnya:
              </div>
              <div className="space-y-3">
                {recentQuestions.map((item, index) => (
                  <div key={index} className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-indigo-100 dark:border-indigo-800/50 text-sm">
                    <div className="font-medium mb-1">{item.question}</div>
                    <div className="text-gray-600 dark:text-gray-400 line-clamp-2">{item.answer}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Featured Hadith Card */}
      <div className="card bg-gradient-to-br from-amber-50 to-amber-100 dark:from-gray-800 dark:to-gray-900 overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Hadits Pilihan</h2>
          <button 
            onClick={() => navigate('/hadith')}
            className="text-xs text-amber-600 dark:text-amber-400 font-medium border border-amber-200 dark:border-amber-800 rounded-md px-2 py-1 hover:bg-amber-50 dark:hover:bg-amber-900/20"
          >
            Lihat Semua
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-amber-200 dark:border-amber-900/30 transition-all duration-500 shadow-sm">
          <div className="arabic-text text-center text-xl mb-3 leading-loose">
            {currentFeaturedHadith.arabic}
          </div>
          <div className="text-center mb-3">
            <p className="italic text-gray-700 dark:text-gray-300">{currentFeaturedHadith.content}</p>
          </div>
          <div className="flex flex-col sm:flex-row justify-between text-sm text-gray-500 dark:text-gray-400 border-t border-amber-100 dark:border-gray-700 pt-3 mt-3">
            <p>{currentFeaturedHadith.source}</p>
            <p>Diriwayatkan oleh: {currentFeaturedHadith.narrator}</p>
          </div>
        </div>

        <div className="flex justify-center mt-3">
          <div className="flex gap-1">
            {featuredHadiths.map((_, index) => (
              <button 
                key={index} 
                onClick={() => setFeaturedHadithIndex(index)}
                className={`w-2 h-2 rounded-full ${
                  index === featuredHadithIndex 
                    ? 'bg-amber-500 dark:bg-amber-400' 
                    : 'bg-amber-200 dark:bg-gray-600'
                }`}
                aria-label={`View hadith ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
