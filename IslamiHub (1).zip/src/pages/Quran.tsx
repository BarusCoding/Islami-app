import { useState, useEffect } from 'react';
import axios from 'axios';
import { ArrowLeft, Info, Loader, Search, ToggleLeft, ToggleRight } from 'lucide-react';

interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  translation: string;
}

interface SurahDetail extends Surah {
  ayahs: Ayah[];
}

// Function to apply tajwid coloring to text
const applyTajwid = (text: string): JSX.Element => {
  // Basic pattern replacements for common tajwid rules
  
  // Ghunnah (ن/م with tashdid/shaddah)
  const ghunnah = text.replace(/(نّ|مّ)/g, '<span class="text-red-500">$1</span>');
  
  // Idgham (merging of letters)
  const idgham = ghunnah.replace(/(ن\s*[يومنر]|نْ\s*[يومنر])/g, '<span class="text-blue-500">$1</span>');
  
  // Ikhfa (partial hiding of nun/tanwin)
  const ikhfa = idgham.replace(/(ن\s*[تثجدذزسشصضطظفقك]|نْ\s*[تثجدذزسشصضطظفقك])/g, '<span class="text-green-500">$1</span>');
  
  // Iqlab (conversion of nun to mim)
  const iqlab = ikhfa.replace(/(ن\s*ب|نْ\s*ب)/g, '<span class="text-purple-500">$1</span>');
  
  // Qalqalah (bouncing sound in certain letters) - ق ط ب ج د
  const qalqalah = iqlab.replace(/([قطبجد]ْ)/g, '<span class="text-orange-500">$1</span>');
  
  // Tafkhim (heavy pronunciation) for specific letters like ص ض ط ظ
  const tafkhim = qalqalah.replace(/([صضطظ])/g, '<span class="text-amber-700">$1</span>');

  // Maddah (prolongation)
  const maddah = tafkhim.replace(/(آ|ـَا|ـُو|ـِي)/g, '<span class="text-indigo-500">$1</span>');
  
  return <div dangerouslySetInnerHTML={{ __html: maddah }} />;
};

const Quran = () => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSurah, setSelectedSurah] = useState<SurahDetail | null>(null);
  const [loadingSurah, setLoadingSurah] = useState(false);
  const [enableTajwid, setEnableTajwid] = useState<boolean>(() => {
    return localStorage.getItem('enableTajwid') === 'true';
  });
  const [showTajwidLegend, setShowTajwidLegend] = useState(false);

  useEffect(() => {
    localStorage.setItem('enableTajwid', enableTajwid.toString());
  }, [enableTajwid]);

  useEffect(() => {
    const fetchSurahs = async () => {
      try {
        const response = await axios.get('https://api.alquran.cloud/v1/surah');
        setSurahs(response.data.data);
      } catch (error) {
        console.error('Error fetching Quran data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSurahs();
  }, []);

  const filteredSurahs = surahs.filter(surah => 
    surah.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    surah.englishName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const fetchSurahDetail = async (surahNumber: number) => {
    setLoadingSurah(true);
    try {
      // Fetch Arabic text
      const arabicResponse = await axios.get(`https://api.alquran.cloud/v1/surah/${surahNumber}`);
      const arabicData = arabicResponse.data.data;
      
      // Fetch Indonesian translation
      const translationResponse = await axios.get(`https://api.alquran.cloud/v1/surah/${surahNumber}/id.indonesian`);
      const translationData = translationResponse.data.data;
      
      // Combine the data
      const ayahs = arabicData.ayahs.map((ayah: any, index: number) => ({
        number: ayah.number,
        numberInSurah: ayah.numberInSurah,
        text: ayah.text,
        translation: translationData.ayahs[index].text
      }));
      
      setSelectedSurah({
        ...arabicData,
        ayahs
      });
    } catch (error) {
      console.error('Error fetching surah details:', error);
    } finally {
      setLoadingSurah(false);
    }
  };

  const handleSurahClick = (surah: Surah) => {
    fetchSurahDetail(surah.number);
  };

  const handleBackToList = () => {
    setSelectedSurah(null);
  };

  const toggleTajwid = () => {
    setEnableTajwid(!enableTajwid);
  };

  const tajwidLegend = [
    { color: 'text-red-500', rule: 'Ghunnah', description: 'Huruf ن/م dengan tasydid' },
    { color: 'text-blue-500', rule: 'Idgham', description: 'Pengucapan nun mati/tanwin yang bertemu huruf ي و م ن ر ل' },
    { color: 'text-green-500', rule: 'Ikhfa', description: 'Pengucapan nun mati/tanwin secara samar dengan huruf ت ث ج د ذ ز س ش ص ض ط ظ ف ق ك' },
    { color: 'text-purple-500', rule: 'Iqlab', description: 'Perubahan bunyi nun mati/tanwin bertemu huruf ب' },
    { color: 'text-orange-500', rule: 'Qalqalah', description: 'Huruf ق ط ب ج د yang berbunyi memantul' },
    { color: 'text-amber-700', rule: 'Tafkhim', description: 'Pengucapan tebal untuk huruf ص ض ط ظ' },
    { color: 'text-indigo-500', rule: 'Maddah', description: 'Pemanjangan bacaan' },
  ];

  if (selectedSurah) {
    return (
      <div className="max-w-4xl mx-auto pb-8">
        <button 
          onClick={handleBackToList}
          className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium mb-4"
        >
          <ArrowLeft size={16} />
          Kembali ke daftar surah
        </button>

        <div className="card mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">{selectedSurah.englishName}</h1>
              <p className="text-gray-600 dark:text-gray-400">{selectedSurah.englishNameTranslation}</p>
            </div>
            <div className="arabic-text text-3xl">{selectedSurah.name}</div>
          </div>
          <div className="flex justify-between items-center mt-2 text-sm text-gray-500 dark:text-gray-400">
            <span>{selectedSurah.revelationType}</span>
            <span>{selectedSurah.numberOfAyahs} Ayat</span>
          </div>
        </div>

        <div className="card mb-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <button 
                onClick={toggleTajwid}
                className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400"
              >
                {enableTajwid ? (
                  <>
                    <ToggleRight size={20} />
                    <span>Tajwid Aktif</span>
                  </>
                ) : (
                  <>
                    <ToggleLeft size={20} />
                    <span>Tajwid Nonaktif</span>
                  </>
                )}
              </button>
            </div>
            
            <button 
              onClick={() => setShowTajwidLegend(!showTajwidLegend)}
              className="flex items-center gap-1 text-blue-600 dark:text-blue-400"
            >
              <Info size={16} />
              <span>Keterangan Tajwid</span>
            </button>
          </div>

          {showTajwidLegend && (
            <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-800">
              <h3 className="font-medium mb-2">Keterangan Warna Tajwid:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {tajwidLegend.map((item, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className={`${item.color} font-bold min-w-[20px] text-center`}>●</div>
                    <div>
                      <span className="font-medium">{item.rule}:</span> {item.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {loadingSurah ? (
          <div className="flex justify-center py-10">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {selectedSurah.ayahs.map((ayah) => (
              <div key={ayah.number} className="card">
                <div className="flex justify-between items-center mb-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-full font-semibold text-sm">
                    {ayah.numberInSurah}
                  </div>
                </div>
                
                <div className="arabic-text text-2xl leading-loose text-right mb-4 pt-2">
                  {enableTajwid ? (
                    applyTajwid(ayah.text)
                  ) : (
                    ayah.text
                  )}
                </div>
                
                <div className="border-t border-gray-200 dark:border-gray-700 pt-4 text-gray-800 dark:text-gray-200">
                  {ayah.translation}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Al-Quran</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Baca Al-Quran dengan terjemahan bahasa Indonesia dari Kementerian Agama RI
        </p>
      </div>

      <div className="mb-6 relative">
        <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
          <Search size={18} className="text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Cari surat..."
          className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <div className="flex flex-col items-center">
            <Loader className="h-10 w-10 animate-spin text-emerald-500" />
            <p className="mt-4 text-gray-600 dark:text-gray-400">Memuat daftar surah...</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredSurahs.map((surah) => (
            <div 
              key={surah.number}
              className="card hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => handleSurahClick(surah)}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-full font-semibold">
                  {surah.number}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="font-semibold">{surah.englishName}</h2>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{surah.englishNameTranslation}</p>
                    </div>
                    <div className="arabic-text text-xl">{surah.name}</div>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-2">
                    <span>{surah.revelationType}</span>
                    <span>{surah.numberOfAyahs} Ayat</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Quran;
