import { useState } from 'react';
import { Calculator, CircleHelp, RefreshCcw } from 'lucide-react';

type ZakatType = 'maal' | 'profesi' | 'fitrah' | 'perdagangan' | 'emas';

interface ZakatInfo {
  title: string;
  description: string;
  nisab: string;
  rate: string;
  period: string;
}

const zakatTypeInfo: Record<ZakatType, ZakatInfo> = {
  maal: {
    title: 'Zakat Maal (Harta)',
    description: 'Zakat harta adalah zakat yang dikeluarkan dari harta yang dimiliki oleh seorang Muslim ketika telah mencapai nisab dan haul.',
    nisab: '85 gram emas (± Rp 79.900.000)',
    rate: '2.5% dari total harta',
    period: 'Setelah kepemilikan mencapai 1 tahun'
  },
  profesi: {
    title: 'Zakat Profesi (Penghasilan)',
    description: 'Zakat profesi adalah zakat yang dikeluarkan dari penghasilan yang diperoleh dari pekerjaan yang dilakukan secara rutin.',
    nisab: '85 gram emas per tahun atau 520 kg beras (± Rp 5.460.000 per bulan)',
    rate: '2.5% dari total penghasilan',
    period: 'Setiap menerima penghasilan (bulanan)'
  },
  fitrah: {
    title: 'Zakat Fitrah',
    description: 'Zakat fitrah adalah zakat yang diwajibkan kepada setiap Muslim pada bulan Ramadhan sebelum Hari Raya Idul Fitri.',
    nisab: 'Tidak ada nisab minimum',
    rate: '2.5 kg - 3.5 kg beras (atau setara uang)',
    period: 'Sebelum Idul Fitri (Ramadhan)'
  },
  perdagangan: {
    title: 'Zakat Perdagangan',
    description: 'Zakat perdagangan adalah zakat yang dikeluarkan dari aset perdagangan (modal kerja + keuntungan - hutang).',
    nisab: '85 gram emas (± Rp 79.900.000)',
    rate: '2.5% dari total aset perdagangan',
    period: 'Setelah kepemilikan mencapai 1 tahun'
  },
  emas: {
    title: 'Zakat Emas & Perak',
    description: 'Zakat emas dan perak adalah zakat yang dikeluarkan dari kepemilikan emas, perak, atau logam mulia lain yang mencapai nisab.',
    nisab: '85 gram emas atau 595 gram perak',
    rate: '2.5% dari total nilai',
    period: 'Setelah kepemilikan mencapai 1 tahun'
  },
};

const goldPricePerGram = 940000; // Harga emas per gram dalam Rupiah
const silverPricePerGram = 12500; // Harga perak per gram dalam Rupiah
const ricePrice = 13000; // Harga beras per kg dalam Rupiah

const Zakat = () => {
  const [zakatType, setZakatType] = useState<ZakatType>('maal');
  const [amount, setAmount] = useState<string>('');
  const [goldAmount, setGoldAmount] = useState<string>('');
  const [silverAmount, setSilverAmount] = useState<string>('');
  const [familyCount, setFamilyCount] = useState<string>('1');
  const [result, setResult] = useState<number | null>(null);
  const [showInfo, setShowInfo] = useState(false);

  const goldNisab = 85 * goldPricePerGram;
  const silverNisab = 595 * silverPricePerGram;

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const calculateZakat = () => {
    let zakatAmount = 0;
    
    switch (zakatType) {
      case 'maal':
        const maalAmount = parseFloat(amount) || 0;
        if (maalAmount >= goldNisab) {
          zakatAmount = maalAmount * 0.025;
        }
        break;
      
      case 'profesi':
        const monthlyIncome = parseFloat(amount) || 0;
        // Monthly nisab is yearly nisab divided by 12
        const monthlyNisab = goldNisab / 12;
        if (monthlyIncome >= monthlyNisab) {
          zakatAmount = monthlyIncome * 0.025;
        }
        break;
      
      case 'fitrah':
        const people = parseInt(familyCount) || 1;
        // 2.5 kg beras per orang
        zakatAmount = people * 2.5 * ricePrice;
        break;
      
      case 'perdagangan':
        const businessAssets = parseFloat(amount) || 0;
        if (businessAssets >= goldNisab) {
          zakatAmount = businessAssets * 0.025;
        }
        break;
      
      case 'emas':
        const goldValue = (parseFloat(goldAmount) || 0) * goldPricePerGram;
        const silverValue = (parseFloat(silverAmount) || 0) * silverPricePerGram;
        const totalValue = goldValue + silverValue;
        
        if ((parseFloat(goldAmount) || 0) >= 85 || (parseFloat(silverAmount) || 0) >= 595) {
          zakatAmount = totalValue * 0.025;
        }
        break;
    }
    
    setResult(zakatAmount);
  };

  const resetForm = () => {
    setAmount('');
    setGoldAmount('');
    setSilverAmount('');
    setFamilyCount('1');
    setResult(null);
  };

  const handleTypeChange = (newType: ZakatType) => {
    setZakatType(newType);
    resetForm();
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Kalkulator Zakat</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Hitung zakat sesuai dengan ketentuan syariat Islam
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <button
          onClick={() => handleTypeChange('maal')}
          className={`p-3 rounded-lg text-center ${
            zakatType === 'maal' 
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 font-medium' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }`}
        >
          Zakat Maal
        </button>
        <button
          onClick={() => handleTypeChange('profesi')}
          className={`p-3 rounded-lg text-center ${
            zakatType === 'profesi' 
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 font-medium' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }`}
        >
          Zakat Profesi
        </button>
        <button
          onClick={() => handleTypeChange('fitrah')}
          className={`p-3 rounded-lg text-center ${
            zakatType === 'fitrah' 
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 font-medium' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }`}
        >
          Zakat Fitrah
        </button>
        <button
          onClick={() => handleTypeChange('perdagangan')}
          className={`p-3 rounded-lg text-center ${
            zakatType === 'perdagangan' 
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 font-medium' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }`}
        >
          Zakat Perdagangan
        </button>
        <button
          onClick={() => handleTypeChange('emas')}
          className={`p-3 rounded-lg text-center ${
            zakatType === 'emas' 
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 font-medium' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }`}
        >
          Zakat Emas & Perak
        </button>
        <button
          onClick={() => setShowInfo(!showInfo)}
          className="p-3 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 flex items-center justify-center gap-2"
        >
          <CircleHelp size={16} />
          <span>Info Zakat</span>
        </button>
      </div>
      
      {showInfo && (
        <div className="card mb-6 bg-blue-50 dark:bg-blue-900/10 border border-blue-200 dark:border-blue-800">
          <h2 className="text-lg font-semibold mb-2">{zakatTypeInfo[zakatType].title}</h2>
          <p className="mb-3 text-gray-700 dark:text-gray-300">{zakatTypeInfo[zakatType].description}</p>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="font-medium">Nisab:</span>
              <span>{zakatTypeInfo[zakatType].nisab}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Kadar Zakat:</span>
              <span>{zakatTypeInfo[zakatType].rate}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Waktu Pengeluaran:</span>
              <span>{zakatTypeInfo[zakatType].period}</span>
            </div>
          </div>

          <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/10 rounded-lg border border-yellow-200 dark:border-yellow-800 text-sm">
            <p>
              <span className="font-semibold">Catatan:</span> Nisab emas saat ini setara dengan {formatCurrency(goldNisab)} 
              (berdasarkan harga emas {formatCurrency(goldPricePerGram)}/gram).
            </p>
          </div>
        </div>
      )}

      <div className="card mb-6">
        <h2 className="text-lg font-semibold mb-4">{zakatTypeInfo[zakatType].title}</h2>
        
        <div className="space-y-4">
          {(zakatType === 'maal' || zakatType === 'profesi' || zakatType === 'perdagangan') && (
            <div>
              <label htmlFor="amount" className="block text-sm font-medium mb-1">
                {zakatType === 'maal' ? 'Total Harta (Rp)' : 
                  zakatType === 'profesi' ? 'Penghasilan Bulanan (Rp)' : 
                  'Total Aset Perdagangan (Rp)'}
              </label>
              <input
                type="number"
                id="amount"
                className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Masukkan jumlah"
                min="0"
              />
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Nisab: {formatCurrency(goldNisab)}
              </p>
            </div>
          )}
          
          {zakatType === 'fitrah' && (
            <div>
              <label htmlFor="familyCount" className="block text-sm font-medium mb-1">
                Jumlah Anggota Keluarga
              </label>
              <input
                type="number"
                id="familyCount"
                className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={familyCount}
                onChange={(e) => setFamilyCount(e.target.value)}
                placeholder="Jumlah anggota keluarga"
                min="1"
              />
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Harga beras: {formatCurrency(ricePrice)}/kg
              </p>
            </div>
          )}
          
          {zakatType === 'emas' && (
            <>
              <div>
                <label htmlFor="goldAmount" className="block text-sm font-medium mb-1">
                  Jumlah Emas (gram)
                </label>
                <input
                  type="number"
                  id="goldAmount"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={goldAmount}
                  onChange={(e) => setGoldAmount(e.target.value)}
                  placeholder="Masukkan jumlah emas (gram)"
                  min="0"
                />
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Nisab emas: 85 gram (≈ {formatCurrency(85 * goldPricePerGram)})
                </p>
              </div>
              
              <div>
                <label htmlFor="silverAmount" className="block text-sm font-medium mb-1">
                  Jumlah Perak (gram)
                </label>
                <input
                  type="number"
                  id="silverAmount"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={silverAmount}
                  onChange={(e) => setSilverAmount(e.target.value)}
                  placeholder="Masukkan jumlah perak (gram)"
                  min="0"
                />
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Nisab perak: 595 gram (≈ {formatCurrency(595 * silverPricePerGram)})
                </p>
              </div>
            </>
          )}
          
          <div className="flex gap-3 pt-2">
            <button
              onClick={calculateZakat}
              className="flex-1 flex items-center justify-center gap-2 btn btn-primary py-3"
            >
              <Calculator size={18} />
              <span>Hitung Zakat</span>
            </button>
            
            <button
              onClick={resetForm}
              className="p-3 rounded-md bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600"
              aria-label="Reset form"
            >
              <RefreshCcw size={18} />
            </button>
          </div>
        </div>
      </div>
      
      {result !== null && (
        <div className="card bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-200 dark:border-emerald-800">
          <h2 className="text-lg font-semibold mb-3">Hasil Perhitungan</h2>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg mb-4">
            <p className="text-gray-600 dark:text-gray-400 mb-1">Jumlah zakat yang harus dikeluarkan:</p>
            <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(result)}
            </p>
          </div>
          
          <div className="text-sm text-gray-600 dark:text-gray-400">
            <p>
              Hasil perhitungan ini hanya sebagai perkiraan. Untuk lebih akuratnya, konsultasikan dengan 
              ahli fiqih atau lembaga zakat resmi.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Zakat;
