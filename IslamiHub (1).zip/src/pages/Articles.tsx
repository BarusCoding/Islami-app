import { useState } from 'react';

interface Article {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  imageUrl: string;
}

const articles: Article[] = [
  {
    id: 1,
    title: "Pentingnya Shalat 5 Waktu dalam Kehidupan Muslim",
    excerpt: "Shalat lima waktu merupakan salah satu rukun Islam yang wajib dilaksanakan oleh setiap Muslim. Artikel ini membahas tentang makna dan hikmah di balik kewajiban shalat.",
    category: "Ibadah",
    imageUrl: "https://images.unsplash.com/photo-1519817650390-64a93db51149?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 2,
    title: "Ramadhan: Bulan Penuh Berkah dan Ampunan",
    excerpt: "Ramadhan adalah bulan suci yang dinantikan oleh seluruh umat Muslim di dunia. Simak penjelasan tentang keutamaan bulan Ramadhan dan tips untuk memaksimalkan ibadah di bulan suci ini.",
    category: "Ramadhan",
    imageUrl: "https://images.unsplash.com/photo-1532339742492-4661c33e8d4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 3,
    title: "Adab dan Etika dalam Islam",
    excerpt: "Islam sangat menekankan pentingnya adab dan etika dalam kehidupan sehari-hari. Artikel ini membahas tentang berbagai adab dalam Islam, mulai dari adab makan, adab berpakaian, hingga adab dalam berinteraksi dengan sesama.",
    category: "Akhlak",
    imageUrl: "https://images.unsplash.com/photo-1541935922804-4e5a39d05ca4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 4,
    title: "Mengenal Asmaul Husna dan Maknanya",
    excerpt: "Asmaul Husna adalah 99 nama Allah yang indah. Setiap nama memiliki makna yang dalam dan mencerminkan sifat-sifat Allah SWT. Artikel ini menjelaskan tentang beberapa Asmaul Husna dan maknanya dalam kehidupan.",
    category: "Aqidah",
    imageUrl: "https://images.unsplash.com/photo-1591429939960-b7d5add10a5c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 5,
    title: "Kisah Inspiratif Para Sahabat Nabi",
    excerpt: "Para sahabat Nabi Muhammad SAW adalah generasi terbaik umat Islam. Artikel ini menceritakan beberapa kisah inspiratif para sahabat yang dapat menjadi teladan bagi kita semua.",
    category: "Sejarah",
    imageUrl: "https://images.unsplash.com/photo-1564549303795-e40162241272?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
  }
];

const categories = ["Semua", "Ibadah", "Ramadhan", "Akhlak", "Aqidah", "Sejarah"];

const Articles = () => {
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredArticles = articles.filter(article => {
    const matchesCategory = selectedCategory === "Semua" || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Artikel Islami</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Kumpulan artikel seputar Islam untuk menambah wawasan keislaman
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Cari artikel..."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <select
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredArticles.length === 0 ? (
          <div className="col-span-full card text-center py-8">
            <p>Tidak ada artikel yang ditemukan</p>
          </div>
        ) : (
          filteredArticles.map(article => (
            <div key={article.id} className="card hover:shadow-md transition-shadow cursor-pointer overflow-hidden">
              <div className="mb-3 h-48 overflow-hidden rounded-lg">
                <img 
                  src={article.imageUrl} 
                  alt={article.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                />
              </div>
              <div className="px-1">
                <div className="inline-block px-3 py-1 text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-200 rounded-full mb-2">
                  {article.category}
                </div>
                <h2 className="text-lg font-semibold mb-2">{article.title}</h2>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{article.excerpt}</p>
                <div className="text-right">
                  <button className="text-emerald-600 dark:text-emerald-400 font-medium text-sm">
                    Baca Selengkapnya
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Articles;
