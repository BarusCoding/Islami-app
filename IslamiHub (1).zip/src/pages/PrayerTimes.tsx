import { useState, useEffect } from 'react';
import axios from 'axios';
import { Bell, BellOff, ChevronDown, MapPin } from 'lucide-react';

interface PrayerTime {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

interface LocationItem {
  id: string;
  name: string;
}

interface District {
  id: string;
  name: string;
  subdistricts: LocationItem[];
}

// Data for North Sumatra districts and subdistricts
const sumateraUtaraDistricts: District[] = [
  {
    id: 'medan',
    name: 'Kota Medan',
    subdistricts: [
      { id: 'medan_kota', name: 'Medan Kota' },
      { id: 'medan_selayang', name: 'Medan Selayang' },
      { id: 'medan_sunggal', name: 'Medan Sunggal' },
      { id: 'medan_helvetia', name: 'Medan Helvetia' },
      { id: 'medan_denai', name: 'Medan Denai' },
      { id: 'medan_barat', name: 'Medan Barat' },
      { id: 'medan_timur', name: 'Medan Timur' },
      { id: 'medan_tuntungan', name: 'Medan Tuntungan' },
      { id: 'medan_belawan', name: 'Medan Belawan' },
      { id: 'medan_amplas', name: 'Medan Amplas' }
    ]
  },
  {
    id: 'binjai',
    name: 'Kota Binjai',
    subdistricts: [
      { id: 'binjai_utara', name: 'Binjai Utara' },
      { id: 'binjai_kota', name: 'Binjai Kota' },
      { id: 'binjai_barat', name: 'Binjai Barat' },
      { id: 'binjai_timur', name: 'Binjai Timur' },
      { id: 'binjai_selatan', name: 'Binjai Selatan' }
    ]
  },
  {
    id: 'karo',
    name: 'Kabupaten Karo',
    subdistricts: [
      { id: 'kabanjahe', name: 'Kabanjahe' },
      { id: 'berastagi', name: 'Berastagi' },
      { id: 'simpang_empat', name: 'Simpang Empat' },
      { id: 'tiga_panah', name: 'Tiga Panah' },
      { id: 'merdeka', name: 'Merdeka' },
      { id: 'tiga_binanga', name: 'Tiga Binanga' },
      { id: 'merek', name: 'Merek' },
      { id: 'juhar', name: 'Juhar' },
      { id: 'tigalingga', name: 'Tigalingga' },
      { id: 'dolat_rayat', name: 'Dolat Rayat' },
      { id: 'laubaleng', name: 'Laubaleng' },
      { id: 'barusjahe', name: 'Barusjahe' },
      { id: 'payung', name: 'Payung' }
    ]
  },
  {
    id: 'deli_serdang',
    name: 'Kabupaten Deli Serdang',
    subdistricts: [
      { id: 'lubuk_pakam', name: 'Lubuk Pakam' },
      { id: 'tanjung_morawa', name: 'Tanjung Morawa' },
      { id: 'percut_sei_tuan', name: 'Percut Sei Tuan' },
      { id: 'batang_kuis', name: 'Batang Kuis' },
      { id: 'sunggal', name: 'Sunggal' },
      { id: 'hamparan_perak', name: 'Hamparan Perak' },
      { id: 'labuhan_deli', name: 'Labuhan Deli' },
      { id: 'patumbak', name: 'Patumbak' }
    ]
  },
  {
    id: 'simalungun',
    name: 'Kabupaten Simalungun',
    subdistricts: [
      { id: 'pematang_siantar', name: 'Pematang Siantar' },
      { id: 'siantar', name: 'Siantar' },
      { id: 'tanah_jawa', name: 'Tanah Jawa' },
      { id: 'dolok_silau', name: 'Dolok Silau' },
      { id: 'hutabayu_raja', name: 'Hutabayu Raja' }
    ]
  },
  {
    id: 'asahan',
    name: 'Kabupaten Asahan',
    subdistricts: [
      { id: 'kisaran_barat', name: 'Kisaran Barat' },
      { id: 'kisaran_timur', name: 'Kisaran Timur' },
      { id: 'air_joman', name: 'Air Joman' },
      { id: 'sei_dadap', name: 'Sei Dadap' },
      { id: 'tanjung_balai', name: 'Tanjung Balai' }
    ]
  },
  {
    id: 'langkat',
    name: 'Kabupaten Langkat',
    subdistricts: [
      { id: 'stabat', name: 'Stabat' },
      { id: 'binjai', name: 'Binjai' },
      { id: 'secanggang', name: 'Secanggang' },
      { id: 'tanjung_pura', name: 'Tanjung Pura' },
      { id: 'babalan', name: 'Babalan' }
    ]
  },
  {
    id: 'tebing_tinggi',
    name: 'Kota Tebing Tinggi',
    subdistricts: [
      { id: 'tebing_tinggi_kota', name: 'Tebing Tinggi Kota' },
      { id: 'bajenis', name: 'Bajenis' },
      { id: 'padang_hilir', name: 'Padang Hilir' },
      { id: 'padang_hulu', name: 'Padang Hulu' },
      { id: 'rambutan', name: 'Rambutan' }
    ]
  },
  {
    id: 'pematangsiantar',
    name: 'Kota Pematangsiantar',
    subdistricts: [
      { id: 'siantar_barat', name: 'Siantar Barat' },
      { id: 'siantar_timur', name: 'Siantar Timur' },
      { id: 'siantar_utara', name: 'Siantar Utara' },
      { id: 'siantar_selatan', name: 'Siantar Selatan' }
    ]
  },
  {
    id: 'tanjungbalai',
    name: 'Kota Tanjungbalai',
    subdistricts: [
      { id: 'tanjungbalai_selatan', name: 'Tanjungbalai Selatan' },
      { id: 'tanjungbalai_utara', name: 'Tanjungbalai Utara' },
      { id: 'datuk_bandar', name: 'Datuk Bandar' },
      { id: 'sei_tualang_raso', name: 'Sei Tualang Raso' }
    ]
  },
  {
    id: 'sibolga',
    name: 'Kota Sibolga',
    subdistricts: [
      { id: 'sibolga_utara', name: 'Sibolga Utara' },
      { id: 'sibolga_selatan', name: 'Sibolga Selatan' },
      { id: 'sibolga_kota', name: 'Sibolga Kota' },
      { id: 'sibolga_sambas', name: 'Sibolga Sambas' }
    ]
  }
];

// Special prayer times for Barusjahe region
const barusjahePrayerTimes = {
  fajr: '05:20', // Fixed Subuh prayer time for Barusjahe
  sunrise: '06:40',
  dhuhr: '12:20',
  asr: '15:40',
  maghrib: '18:15',
  isha: '19:30'
};

// Other Indonesian cities for the dropdown
const cities = [
  'Jakarta', 'Surabaya', 'Bandung', 'Makassar', 'Semarang', 
  'Palembang', 'Tangerang', 'Depok', 'Bekasi',
  'Padang', 'Malang', 'Yogyakarta', 'Denpasar', 'Manado'
];

const provinces = [
  { id: 'sumatera_utara', name: 'Sumatera Utara' },
  { id: 'aceh', name: 'Aceh' },
  { id: 'sumatera_barat', name: 'Sumatera Barat' },
  { id: 'riau', name: 'Riau' },
  { id: 'jambi', name: 'Jambi' },
  { id: 'sumatera_selatan', name: 'Sumatera Selatan' },
  { id: 'bengkulu', name: 'Bengkulu' },
  { id: 'lampung', name: 'Lampung' },
  { id: 'jakarta', name: 'DKI Jakarta' },
  { id: 'jawa_barat', name: 'Jawa Barat' },
  { id: 'jawa_tengah', name: 'Jawa Tengah' },
  { id: 'yogyakarta', name: 'DI Yogyakarta' },
  { id: 'jawa_timur', name: 'Jawa Timur' },
  { id: 'bali', name: 'Bali' }
];

const PrayerTimes = () => {
  const [selectedProvince, setSelectedProvince] = useState('sumatera_utara');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedSubdistrict, setSelectedSubdistrict] = useState('');
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime | null>(null);
  const [loading, setLoading] = useState(true);
  const [date, setDate] = useState(new Date());
  const [availableDistricts, setAvailableDistricts] = useState<District[]>(sumateraUtaraDistricts);
  const [availableSubdistricts, setAvailableSubdistricts] = useState<LocationItem[]>([]);
  const [locationDisplayName, setLocationDisplayName] = useState('Sumatera Utara');
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    return localStorage.getItem('prayerNotifications') === 'true';
  });
  const [gpsLocation, setGpsLocation] = useState({ lat: 0, lng: 0 });
  const [usingGPS, setUsingGPS] = useState(false);

  // Initialize with saved preferences
  useEffect(() => {
    const savedProvince = localStorage.getItem('selectedProvince');
    const savedDistrict = localStorage.getItem('selectedDistrict');
    const savedSubdistrict = localStorage.getItem('selectedSubdistrict');

    if (savedProvince) setSelectedProvince(savedProvince);
    if (savedDistrict) setSelectedDistrict(savedDistrict);
    if (savedSubdistrict) setSelectedSubdistrict(savedSubdistrict);

    // If Sumatera Utara is selected, we use the district/subdistrict data
    if (savedProvince === 'sumatera_utara' || !savedProvince) {
      setAvailableDistricts(sumateraUtaraDistricts);
      
      if (savedDistrict) {
        const district = sumateraUtaraDistricts.find(d => d.id === savedDistrict);
        if (district) {
          setAvailableSubdistricts(district.subdistricts);
          
          if (savedSubdistrict) {
            const subdistrict = district.subdistricts.find(s => s.id === savedSubdistrict);
            if (subdistrict) {
              setLocationDisplayName(`${subdistrict.name}, ${district.name}, Sumatera Utara`);
            } else {
              setLocationDisplayName(`${district.name}, Sumatera Utara`);
            }
          } else {
            setLocationDisplayName(`${district.name}, Sumatera Utara`);
          }
        }
      }
    } else if (savedProvince) {
      // For other provinces, we use the city dropdown
      const province = provinces.find(p => p.id === savedProvince);
      if (province) {
        setLocationDisplayName(province.name);
        if (savedDistrict) {
          setLocationDisplayName(`${savedDistrict}, ${province.name}`);
          setSelectedCity(savedDistrict);
        }
      }
    }

    // Try to get user's actual location if they haven't set a preference
    if (!savedProvince && !savedDistrict && 'geolocation' in navigator) {
      getGPSLocation();
    }
  }, []);

  const getGPSLocation = () => {
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setGpsLocation({ lat: latitude, lng: longitude });
        setUsingGPS(true);
        
        try {
          // Get location name from coordinates
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          if (response.data) {
            setLocationDisplayName(response.data.display_name);
            // Use coordinates for accurate prayer times
            fetchPrayerTimesByCoordinates(latitude, longitude);
          }
        } catch (error) {
          console.error("Error fetching location data:", error);
          // Still fetch prayer times with coordinates even if reverse geocoding fails
          fetchPrayerTimesByCoordinates(latitude, longitude);
        }
      },
      (error) => {
        console.error("Error getting location:", error);
      }
    );
  };

  useEffect(() => {
    // This sets up the available subdistricts when a district is selected
    if (selectedProvince === 'sumatera_utara' && selectedDistrict) {
      const district = sumateraUtaraDistricts.find(d => d.id === selectedDistrict);
      if (district) {
        setAvailableSubdistricts(district.subdistricts);
        
        if (selectedSubdistrict) {
          const subdistrict = district.subdistricts.find(s => s.id === selectedSubdistrict);
          if (subdistrict) {
            setLocationDisplayName(`${subdistrict.name}, ${district.name}, Sumatera Utara`);
          } else {
            setLocationDisplayName(`${district.name}, Sumatera Utara`);
          }
        } else {
          setLocationDisplayName(`${district.name}, Sumatera Utara`);
        }
      }
    } else if (selectedProvince !== 'sumatera_utara' && selectedCity) {
      const province = provinces.find(p => p.id === selectedProvince);
      if (province) {
        setLocationDisplayName(`${selectedCity}, ${province.name}`);
      }
    } else if (selectedProvince) {
      const province = provinces.find(p => p.id === selectedProvince);
      if (province) {
        setLocationDisplayName(province.name);
      }
    }
  }, [selectedProvince, selectedDistrict, selectedSubdistrict, selectedCity]);

  useEffect(() => {
    if (usingGPS && gpsLocation.lat !== 0 && gpsLocation.lng !== 0) {
      fetchPrayerTimesByCoordinates(gpsLocation.lat, gpsLocation.lng);
    } else {
      // Special case for Barusjahe in Kabupaten Karo
      if (selectedProvince === 'sumatera_utara' && 
          selectedDistrict === 'karo' && 
          selectedSubdistrict === 'barusjahe') {
        // Use the fixed prayer times for Barusjahe
        setLoading(false);
        setPrayerTimes(barusjahePrayerTimes);
      } else {
        let locationName = '';
        
        if (selectedProvince === 'sumatera_utara') {
          if (selectedSubdistrict && selectedDistrict) {
            const district = sumateraUtaraDistricts.find(d => d.id === selectedDistrict);
            if (district) {
              const subdistrict = district.subdistricts.find(s => s.id === selectedSubdistrict);
              if (subdistrict) {
                locationName = `${subdistrict.name}, ${district.name}`;
              } else {
                locationName = district.name;
              }
            }
          } else if (selectedDistrict) {
            const district = sumateraUtaraDistricts.find(d => d.id === selectedDistrict);
            if (district) {
              locationName = district.name;
            }
          } else {
            locationName = 'Medan'; // Default location for Sumatera Utara if nothing selected
          }
        } else {
          locationName = selectedCity || 'Jakarta'; // Default to Jakarta if no city selected
        }
        
        fetchPrayerTimes(locationName);
      }
    }
  }, [selectedProvince, selectedDistrict, selectedSubdistrict, selectedCity, date, usingGPS, gpsLocation]);

  const fetchPrayerTimesByCoordinates = async (latitude: number, longitude: number) => {
    setLoading(true);
    try {
      // Use latitude and longitude for more accurate prayer times
      const response = await axios.get(`https://api.aladhan.com/v1/timings`, {
        params: {
          latitude,
          longitude,
          method: 2, // Islamic Society of North America method
          date: `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`
        }
      });
      
      const timings = response.data.data.timings;
      setPrayerTimes({
        fajr: timings.Fajr,
        sunrise: timings.Sunrise,
        dhuhr: timings.Dhuhr,
        asr: timings.Asr,
        maghrib: timings.Maghrib,
        isha: timings.Isha
      });

      // Set up notifications for prayer times if enabled
      if (notificationsEnabled) {
        schedulePrayerNotifications({
          fajr: timings.Fajr,
          dhuhr: timings.Dhuhr,
          asr: timings.Asr,
          maghrib: timings.Maghrib,
          isha: timings.Isha
        });
      }
    } catch (error) {
      console.error('Error fetching prayer times by coordinates:', error);
      // Fallback to city-based method
      fetchPrayerTimes('Jakarta');
    } finally {
      setLoading(false);
    }
  };

  const fetchPrayerTimes = async (location: string) => {
    setLoading(true);
    try {
      // In a real app, you would use a proper prayer times API
      // This is a placeholder request that would be replaced with an actual API
      const response = await axios.get(`https://api.aladhan.com/v1/timingsByCity`, {
        params: {
          city: location,
          country: 'Indonesia',
          method: 2, // Islamic Society of North America method
          date: `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`
        }
      });
      
      const timings = response.data.data.timings;
      setPrayerTimes({
        fajr: timings.Fajr,
        sunrise: timings.Sunrise,
        dhuhr: timings.Dhuhr,
        asr: timings.Asr,
        maghrib: timings.Maghrib,
        isha: timings.Isha
      });

      // Set up notifications for prayer times if enabled
      if (notificationsEnabled) {
        schedulePrayerNotifications({
          fajr: timings.Fajr,
          dhuhr: timings.Dhuhr,
          asr: timings.Asr,
          maghrib: timings.Maghrib,
          isha: timings.Isha
        });
      }
    } catch (error) {
      console.error('Error fetching prayer times:', error);
      // Fallback data for demo purposes
      setPrayerTimes({
        fajr: '04:30',
        sunrise: '05:50',
        dhuhr: '12:05',
        asr: '15:25',
        maghrib: '18:02',
        isha: '19:15'
      });
    } finally {
      setLoading(false);
    }
  };

  const schedulePrayerNotifications = (times: Record<string, string>) => {
    // We'd need to calculate the time until each prayer and set timeouts
    const prayerNames = {
      fajr: "Subuh",
      dhuhr: "Dzuhur",
      asr: "Ashar",
      maghrib: "Maghrib",
      isha: "Isya"
    };
    
    Object.entries(times).forEach(([prayer, time]) => {
      if (prayer in prayerNames) {
        const [hours, minutes] = time.split(':').map(Number);
        const prayerTime = new Date();
        prayerTime.setHours(hours, minutes, 0);
        
        const now = new Date();
        let timeUntilPrayer = prayerTime.getTime() - now.getTime();
        
        // If the prayer time has already passed today, skip it
        if (timeUntilPrayer > 0) {
          setTimeout(() => {
            // This would show a notification when prayer time arrives
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification(`Waktu Shalat ${prayerNames[prayer as keyof typeof prayerNames]}`, {
                body: `Sekarang waktu shalat ${prayerNames[prayer as keyof typeof prayerNames]}: ${time}`,
                icon: "/mosque-icon.png"
              });
              
              // Play adhan sound
              const adhan = new Audio("/adhan.mp3");
              adhan.play().catch(e => console.error("Could not play adhan:", e));
            }
          }, timeUntilPrayer);
        }
      }
    });
  };

  const toggleNotifications = () => {
    if (!notificationsEnabled) {
      // Request permission
      if ("Notification" in window) {
        Notification.requestPermission().then(permission => {
          if (permission === "granted") {
            setNotificationsEnabled(true);
            localStorage.setItem('prayerNotifications', 'true');
            if (prayerTimes) {
              schedulePrayerNotifications(prayerTimes);
            }
          }
        });
      }
    } else {
      setNotificationsEnabled(false);
      localStorage.setItem('prayerNotifications', 'false');
    }
  };

  const handleProvinceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const province = e.target.value;
    setSelectedProvince(province);
    setUsingGPS(false);
    
    if (province === 'sumatera_utara') {
      setAvailableDistricts(sumateraUtaraDistricts);
      setSelectedCity('');
    } else {
      setSelectedDistrict('');
      setSelectedSubdistrict('');
      setAvailableSubdistricts([]);
    }
    
    localStorage.setItem('selectedProvince', province);
  };

  const handleDistrictChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const district = e.target.value;
    setSelectedDistrict(district);
    setSelectedSubdistrict('');
    setUsingGPS(false);
    
    const selectedDistrictObj = sumateraUtaraDistricts.find(d => d.id === district);
    if (selectedDistrictObj) {
      setAvailableSubdistricts(selectedDistrictObj.subdistricts);
    } else {
      setAvailableSubdistricts([]);
    }
    
    localStorage.setItem('selectedDistrict', district);
  };

  const handleSubdistrictChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const subdistrict = e.target.value;
    setSelectedSubdistrict(subdistrict);
    setUsingGPS(false);
    localStorage.setItem('selectedSubdistrict', subdistrict);
  };

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const city = e.target.value;
    setSelectedCity(city);
    setUsingGPS(false);
    localStorage.setItem('selectedDistrict', city); // We reuse the district storage for city
  };

  const handleDateChange = (days: number) => {
    const newDate = new Date(date);
    newDate.setDate(newDate.getDate() + days);
    setDate(newDate);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  const useCurrentLocation = () => {
    if ('geolocation' in navigator) {
      getGPSLocation();
    } else {
      alert('Geolocation tidak didukung oleh browser Anda');
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Jadwal Shalat</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Jadwal shalat untuk seluruh wilayah Indonesia
        </p>
      </div>

      <div className="card mb-6">
        <div className="flex flex-col gap-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="text-emerald-600 dark:text-emerald-400">
                <MapPin size={20} />
              </div>
              <h2 className="text-lg font-medium">Lokasi Terpilih: {locationDisplayName}</h2>
            </div>
            <button
              onClick={toggleNotifications}
              className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm ${
                notificationsEnabled
                  ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400'
                  : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
              }`}
            >
              {notificationsEnabled ? <Bell size={16} /> : <BellOff size={16} />}
              {notificationsEnabled ? 'Notifikasi Aktif' : 'Aktifkan Notifikasi'}
            </button>
          </div>
          
          <button 
            onClick={useCurrentLocation}
            className="w-full py-2 bg-blue-500 text-white rounded-lg flex items-center justify-center gap-2"
          >
            <MapPin size={16} />
            Gunakan Lokasi Saat Ini
          </button>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="province-select" className="block text-sm font-medium mb-1">Provinsi</label>
              <select
                id="province-select"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={selectedProvince}
                onChange={handleProvinceChange}
                disabled={usingGPS}
              >
                {provinces.map((province) => (
                  <option key={province.id} value={province.id}>{province.name}</option>
                ))}
              </select>
            </div>
            
            {selectedProvince === 'sumatera_utara' ? (
              <div>
                <label htmlFor="district-select" className="block text-sm font-medium mb-1">Kabupaten/Kota</label>
                <select
                  id="district-select"
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={selectedDistrict}
                  onChange={handleDistrictChange}
                  disabled={usingGPS}
                >
                  <option value="">Pilih Kabupaten/Kota</option>
                  {availableDistricts.map((district) => (
                    <option key={district.id} value={district.id}>{district.name}</option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label htmlFor="city-select" className="block text-sm font-medium mb-1">Kota</label>
                <select
                  id="city-select"
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={selectedCity}
                  onChange={handleCityChange}
                  disabled={usingGPS}
                >
                  <option value="">Pilih Kota</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>
            )}
            
            {selectedProvince === 'sumatera_utara' && selectedDistrict && (
              <div className="md:col-span-2">
                <label htmlFor="subdistrict-select" className="block text-sm font-medium mb-1">Kecamatan</label>
                <select
                  id="subdistrict-select"
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={selectedSubdistrict}
                  onChange={handleSubdistrictChange}
                  disabled={usingGPS}
                >
                  <option value="">Semua Kecamatan</option>
                  {availableSubdistricts.map((subdistrict) => (
                    <option key={subdistrict.id} value={subdistrict.id}>{subdistrict.name}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Tanggal</label>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDateChange(-1)}
                className="btn btn-secondary py-1 px-3"
                aria-label="Previous day"
              >
                &lt;
              </button>
              <div className="flex-1 text-center py-2 rounded-lg bg-gray-50 dark:bg-gray-700">
                {formatDate(date)}
              </div>
              <button
                onClick={() => handleDateChange(1)}
                className="btn btn-secondary py-1 px-3"
                aria-label="Next day"
              >
                &gt;
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-4">Jadwal Shalat {locationDisplayName}</h2>
        
        {loading ? (
          <div className="flex justify-center py-10">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Subuh</h3>
                <p className="text-2xl font-bold">{prayerTimes?.fajr}</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Terbit</h3>
                <p className="text-2xl font-bold">{prayerTimes?.sunrise}</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Dzuhur</h3>
                <p className="text-2xl font-bold">{prayerTimes?.dhuhr}</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Ashar</h3>
                <p className="text-2xl font-bold">{prayerTimes?.asr}</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Maghrib</h3>
                <p className="text-2xl font-bold">{prayerTimes?.maghrib}</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
                <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Isya</h3>
                <p className="text-2xl font-bold">{prayerTimes?.isha}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PrayerTimes;
