import { useState } from 'react';

interface Prayer {
  id: number;
  title: string;
  arabic: string;
  latin: string;
  translation: string;
  category: string;
}

const prayers: Prayer[] = [
  {
    id: 1,
    title: "Doa Sebelum Makan",
    arabic: "اَللّٰهُمَّ بَارِكْ لَنَا فِيْمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ",
    latin: "Alloohumma baarik lanaa fiimaa rozaqtanaa waqinaa 'adzaa bannaar",
    translation: "Ya Allah, berkahilah rezeki yang telah Engkau berikan kepada kami dan peliharalah kami dari siksa api neraka",
    category: "daily"
  },
  {
    id: 2,
    title: "Doa Sesudah Makan",
    arabic: "اَلْحَمْدُ لِلهِ الَّذِىْ اَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِيْنَ",
    latin: "Alhamdu lillaahil ladzii ath'amanaa wa saqoonaa wa ja'alanaa minal muslimiin",
    translation: "Segala puji bagi Allah yang telah memberi kami makan dan minum serta menjadikan kami termasuk orang-orang muslim",
    category: "daily"
  },
  {
    id: 3,
    title: "Doa Sebelum Tidur",
    arabic: "بِاسْمِكَ اللّٰهُمَّ اَحْيَا وَاَمُوْتُ",
    latin: "Bismikallahumma ahyaa wa amuut",
    translation: "Dengan nama-Mu ya Allah, aku hidup dan aku mati",
    category: "daily"
  },
  {
    id: 4,
    title: "Doa Bangun Tidur",
    arabic: "اَلْحَمْدُ لِلّٰهِ الَّذِيْ أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُوْرُ",
    latin: "Alhamdu lillaahil ladzii ahyaanaa ba'da maa amaatanaa wa ilaihin nusyuur",
    translation: "Segala puji bagi Allah yang telah menghidupkan kami kembali setelah mematikan kami dan kepada-Nya kami dibangkitkan",
    category: "daily"
  },
  {
    id: 5,
    title: "Tasbih Setelah Shalat",
    arabic: "سُبْحَانَ اللهِ",
    latin: "Subhanallah (33x)",
    translation: "Maha Suci Allah",
    category: "prayer"
  },
  {
    id: 6,
    title: "Tahmid Setelah Shalat",
    arabic: "اَلْحَمْدُ لِلهِ",
    latin: "Alhamdulillah (33x)",
    translation: "Segala puji bagi Allah",
    category: "prayer"
  },
  {
    id: 7,
    title: "Takbir Setelah Shalat",
    arabic: "اللهُ أَكْبَرُ",
    latin: "Allahu Akbar (33x)",
    translation: "Allah Maha Besar",
    category: "prayer"
  },
  {
    id: 8,
    title: "Doa Masuk Masjid",
    arabic: "اَللّٰهُمَّ افْتَحْ لِيْ اَبْوَابَ رَحْمَتِكَ",
    latin: "Allahummaftah lii abwaaba rahmatik",
    translation: "Ya Allah, bukalah untukku pintu-pintu rahmat-Mu",
    category: "daily"
  }
];

const Prayers = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filteredPrayers = prayers.filter(prayer => {
    const matchesCategory = selectedCategory === 'all' || prayer.category === selectedCategory;
    const matchesSearch = prayer.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Kumpulan Doa</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Kumpulan doa-doa harian dan setelah shalat
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Cari doa..."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <select
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="all">Semua Kategori</option>
            <option value="daily">Doa Harian</option>
            <option value="prayer">Doa Setelah Shalat</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredPrayers.length === 0 ? (
          <div className="card text-center py-8">
            <p>Tidak ada doa yang ditemukan</p>
          </div>
        ) : (
          filteredPrayers.map(prayer => (
            <div key={prayer.id} className="card overflow-hidden">
              <div 
                className="flex justify-between items-center cursor-pointer"
                onClick={() => toggleExpand(prayer.id)}
              >
                <h2 className="font-semibold">{prayer.title}</h2>
                <div className="w-6 h-6 flex items-center justify-center">
                  <span className="text-lg">{expandedId === prayer.id ? '−' : '+'}</span>
                </div>
              </div>
              
              {expandedId === prayer.id && (
                <div className="mt-4 space-y-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="arabic-text text-xl text-center py-2">
                    {prayer.arabic}
                  </div>
                  <div className="text-gray-600 dark:text-gray-400 italic text-center text-sm">
                    {prayer.latin}
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <p className="text-sm">{prayer.translation}</p>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Prayers;
