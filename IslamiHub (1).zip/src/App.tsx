import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';

// Components
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Quran from './pages/Quran';
import PrayerTimes from './pages/PrayerTimes';
import Prayers from './pages/Prayers';
import Dhikr from './pages/Dhikr';
import Articles from './pages/Articles';
import Hadith from './pages/Hadith';
import Zakat from './pages/Zakat';

export type ThemeType = 'light' | 'dark';

function App() {
  const [theme, setTheme] = useState<ThemeType>(() => {
    const savedTheme = localStorage.getItem('theme') as ThemeType;
    return savedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  });
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <Navbar toggleTheme={toggleTheme} theme={theme} toggleSidebar={toggleSidebar} />
        
        <div className="flex flex-1 relative">
          <Sidebar isOpen={isSidebarOpen} closeSidebar={() => setIsSidebarOpen(false)} />
          
          <main className="flex-1 p-4 md:p-6 overflow-auto">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/quran" element={<Quran />} />
              <Route path="/prayer-times" element={<PrayerTimes />} />
              <Route path="/prayers" element={<Prayers />} />
              <Route path="/dhikr" element={<Dhikr />} />
              <Route path="/articles" element={<Articles />} />
              <Route path="/hadith" element={<Hadith />} />
              <Route path="/zakat" element={<Zakat />} />
            </Routes>
          </main>
        </div>
        
        <Footer />
      </div>
    </Router>
  );
}

export default App;
