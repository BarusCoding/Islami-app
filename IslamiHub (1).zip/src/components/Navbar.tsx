import { Menu, Moon, Sun } from 'lucide-react';
import { ThemeType } from '../App';

interface NavbarProps {
  toggleTheme: () => void;
  theme: ThemeType;
  toggleSidebar: () => void;
}

const Navbar = ({ toggleTheme, theme, toggleSidebar }: NavbarProps) => {
  return (
    <header className="sticky top-0 z-10 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={toggleSidebar}
            className="md:hidden p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Toggle sidebar"
          >
            <Menu size={24} />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 flex items-center justify-center overflow-hidden rounded-full bg-emerald-500 dark:bg-emerald-600">
              <svg viewBox="0 0 24 24" className="w-5 h-5 text-white">
                <path
                  fill="currentColor"
                  d="M2,2V22H22V2H2M20,20H4V4H20V20M18,6H13V14H16V18H18V6M11,6H6V18H11V6M9,16H8V8H9V16M15,8H14V16H15V8Z"
                />
              </svg>
            </div>
            <h1 className="text-xl font-bold">Aplikasi Islami</h1>
          </div>
        </div>
        
        <div className="flex items-center">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
