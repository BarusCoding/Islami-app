import { useNavigate } from 'react-router-dom';
import { Book, Calculator, Clock, FileText, Hash, Heart, House, Moon, X } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const Sidebar = ({ isOpen, closeSidebar }: SidebarProps) => {
  const navigate = useNavigate();
  
  const navigateTo = (path: string) => {
    navigate(path);
    closeSidebar();
  };
  
  const menuItems = [
    { title: 'Beranda', icon: <House size={20} />, path: '/' },
    { title: 'Al-Quran', icon: <Book size={20} />, path: '/quran' },
    { title: 'Jadwal Shalat', icon: <Clock size={20} />, path: '/prayer-times' },
    { title: 'Kumpulan Doa', icon: <Heart size={20} />, path: '/prayers' },
    { title: 'Dzikir Digital', icon: <Hash size={20} />, path: '/dhikr' },
    { title: 'Kalkulator Zakat', icon: <Calculator size={20} />, path: '/zakat' },
    { title: 'Artikel Islami', icon: <FileText size={20} />, path: '/articles' },
    { title: 'Hadits', icon: <Moon size={20} />, path: '/hadith' },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={closeSidebar}
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={`fixed md:static inset-y-0 left-0 w-64 bg-white dark:bg-gray-800 shadow-lg z-30 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 md:hidden">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 flex items-center justify-center overflow-hidden rounded-full bg-emerald-500 dark:bg-emerald-600">
                <svg viewBox="0 0 24 24" className="w-5 h-5 text-white">
                  <path
                    fill="currentColor"
                    d="M2,2V22H22V2H2M20,20H4V4H20V20M18,6H13V14H16V18H18V6M11,6H6V18H11V6M9,16H8V8H9V16M15,8H14V16H15V8Z"
                  />
                </svg>
              </div>
              <h2 className="text-lg font-bold">Aplikasi Islami</h2>
            </div>
            <button
              onClick={closeSidebar}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              aria-label="Close sidebar"
            >
              <X size={20} />
            </button>
          </div>
          
          <nav className="flex-1 overflow-y-auto pt-5">
            <ul className="space-y-1 px-3">
              {menuItems.map((item) => (
                <li key={item.title}>
                  <button
                    onClick={() => navigateTo(item.path)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    {item.icon}
                    <span>{item.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="text-sm text-gray-500 dark:text-gray-400 text-center">
              <p>© 2024 Aplikasi Islami</p>
              <p className="mt-1">Dikembangkan oleh M. RASID SIDIQ BARUS</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
