import { Github, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-4 px-4 mt-auto">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="mb-2 md:mb-0 text-center md:text-left">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            © {new Date().getFullYear()} Aplikasi Islami
          </p>
        </div>
        
        <div className="text-center md:text-right">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Dikembangkan oleh <span className="font-medium text-gray-800 dark:text-gray-300">M. Rasid Sidiq Barus</span>
          </p>
          <div className="flex justify-center md:justify-end mt-2 space-x-3">
            <a 
              href="mailto:contact@example.com" 
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              aria-label="Email"
            >
              <Mail size={16} />
            </a>
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              aria-label="GitHub"
            >
              <Github size={16} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
